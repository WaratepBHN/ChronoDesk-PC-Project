# ChronoDesk starter code / โค้ดเริ่มต้น

Open ChronoDeskCode/ChronoDeskCode.ino in Arduino IDE. Keep all eight frame_000.h–frame_007.h files in the same folder.
เปิด ChronoDeskCode/ChronoDeskCode.ino ด้วย Arduino IDE และเก็บไฟล์ frame ทั้ง 8 ไฟล์ไว้ในโฟลเดอร์เดียวกัน

Replace YOUR_WIFI_SSID, YOUR_WIFI_PASSWORD and YOUR_OPENWEATHER_API_KEY with your own values before uploading. Do not publish credentials.
แทนที่ placeholder ทั้งสามด้วย Wi-Fi และ OpenWeather API key ของคุณก่อนอัปโหลด และอย่าเผยแพร่ข้อมูลเหล่านี้

Select the ESP32-C3 board and install the libraries included by the sketch: ArduinoJson, Adafruit GFX, Adafruit ST7735 and ST7789, and Adafruit SHT31. WiFi, HTTPClient, SPI, Wire and time come with the ESP32 board package.
เลือกบอร์ด ESP32-C3 และติดตั้งไลบรารีตาม #include ใน sketch

The original project includes location coordinates for its weather view; update lat and lon for your location if required. Wiring and pin assignments are documented in HWSpec.md and the circuit diagram on the website.
ปรับ lat และ lon หากต้องการแสดงอากาศของพื้นที่อื่น ตรวจผังวงจรและหมายเลขขาก่อนต่ออุปกรณ์

Source: ChronoDesk-PC-Project / Software (original project files)
